const fs = require("fs");
const path = require("path");
const archiver = require("archiver");

// Create output directory if it doesn't exist
if (!fs.existsSync("dist")) {
  fs.mkdirSync("dist");
}

// Create a file to stream archive data to
const output = fs.createWriteStream("dist/application.zip");
const archive = archiver("zip", {
  zlib: { level: 9 }, // Sets the compression level
});

// Listen for all archive data to be written
output.on("close", function () {
  console.log("Archive created successfully");
  console.log("Total bytes: " + archive.pointer());
});

// Good practice to catch warnings
archive.on("warning", function (err) {
  if (err.code === "ENOENT") {
    console.warn("Warning:", err);
  } else {
    throw err;
  }
});

// Good practice to catch errors
archive.on("error", function (err) {
  throw err;
});

// Pipe archive data to the file
archive.pipe(output);

// Add files and directories
archive.directory("client/", "client");
archive.directory("server/", "server");
archive.directory("shared/", "shared");
archive.file("package.json", { name: "package.json" });
archive.file("package-lock.json", { name: "package-lock.json" });
archive.file("tsconfig.json", { name: "tsconfig.json" });
archive.file("tailwind.config.ts", { name: "tailwind.config.ts" });
archive.file("postcss.config.js", { name: "postcss.config.js" });
archive.file("drizzle.config.ts", { name: "drizzle.config.ts" });
archive.file("theme.json", { name: "theme.json" });

// Finalize the archive
archive.finalize();
